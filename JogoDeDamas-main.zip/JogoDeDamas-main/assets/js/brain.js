window.onload = () => {

    function br(i) {
        console.log(i);
    }

    br(21)
}